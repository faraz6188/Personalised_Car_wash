import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import { useAudio } from '../contexts/AudioContext';
import { ArrowLeft, ArrowRight, Sparkles, User, Music, Heart } from 'lucide-react';
import { generateSong } from '../services/api';
import Logo from '../SgtCleanLogo.png';

const genres = [
  { id: 'pop', name: 'Pop', emoji: '🎵', color: 'from-pink-500 to-rose-500' },
  { id: 'rock', name: 'Rock', emoji: '🎸', color: 'from-red-500 to-orange-500' },
  { id: 'electronic', name: 'Electronic', emoji: '🎛️', color: 'from-cyan-500 to-blue-500' },
  { id: 'jazz', name: 'Jazz', emoji: '🎺', color: 'from-purple-500 to-indigo-500' },
  { id: 'reggae', name: 'Reggae', emoji: '🌴', color: 'from-green-500 to-emerald-500' },
  { id: 'country', name: 'Country', emoji: '🤠', color: 'from-yellow-500 to-amber-500' },
  { id: 'hiphop', name: 'Hip-Hop', emoji: '🎤', color: 'from-gray-700 to-gray-900' },
  { id: 'classical', name: 'Classical', emoji: '🎼', color: 'from-violet-500 to-purple-500' }
];

const moods = ['Energetic', 'Relaxed', 'Happy', 'Chill', 'Upbeat', 'Peaceful'];

const GeneratePage: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isGenerating, setIsGenerating] = useState(false);
  const { preferences, updatePreferences } = useUser();
  const { setSong, setLoading } = useAudio();
  const navigate = useNavigate();

  const handleNext = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleGenerate = async () => {
    if (!preferences.name || !preferences.genre) return;

    setIsGenerating(true);
    setLoading(true);

    try {
      const song = await generateSong(preferences);
      setSong(song);
      navigate('/results');
    } catch (error) {
      console.error('Error generating song:', error);
      alert('Sorry, there was an error generating your song. Please try again.');
    } finally {
      setIsGenerating(false);
      setLoading(false);
    }
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1: return preferences.name.trim().length > 0;
      case 2: return preferences.genre.length > 0;
      case 3: return true;
      default: return false;
    }
  };

  if (isGenerating) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-blue-600 to-cyan-500 flex items-center justify-center">
        <div className="container-mobile text-center text-white">
          <div className="w-32 h-32 mx-auto mb-8 relative">
            <div className="absolute inset-0 border-4 border-white/20 rounded-full animate-spin">
              <div className="absolute top-0 left-1/2 w-2 h-2 bg-white rounded-full transform -translate-x-1/2 -translate-y-1"></div>
            </div>
            <div className="absolute inset-4 bg-white/20 rounded-full flex items-center justify-center">
              <Music className="h-12 w-12 text-white animate-bounce-mobile" />
            </div>
          </div>
          
          <h1 className="text-3xl font-bold mb-4">Creating Your Song...</h1>
          <p className="text-xl mb-8 text-blue-100">AI is composing your 4-minute car wash anthem!</p>
          
          <div className="card-mobile bg-white/10 backdrop-blur-sm">
            <p className="text-lg">🎵 Each song is unique and personalized just for you!</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      <div className="container-mobile pt-8 pb-12">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Sparkles className="h-8 w-8 text-blue-400 mr-2" />
            <h1 className="text-3xl font-bold text-white">Create Your Song</h1>
          </div>
          
          {/* Progress */}
          <div className="flex justify-center space-x-2 mb-4">
            {[1, 2, 3].map((step) => (
              <div
                key={step}
                className={`w-3 h-3 rounded-full transition-all duration-200 ${
                  step === currentStep ? 'bg-blue-600' : step < currentStep ? 'bg-green-500' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
          <p className="text-gray-300">Step {currentStep} of 3</p>
        </div>

        {/* Step Content */}
        <div className="bg-gray-800 rounded-3xl shadow-lg p-6 mb-8 relative overflow-hidden">
          <div className="absolute top-4 right-4 opacity-10">
            <img src={Logo} alt="" className="h-10 w-10" />
          </div>
          {/* Step 1: Name */}
          {currentStep === 1 && (
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <User className="h-8 w-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-4">What's Your Name?</h2>
              <p className="text-gray-300 mb-6">We'll personalize your song with a special greeting!</p>
              
              <input
                type="text"
                value={preferences.name}
                onChange={(e) => updatePreferences({ name: e.target.value })}
                placeholder="Enter your first name"
                className="input-mobile text-center"
                maxLength={50}
                autoFocus
              />
              
              {preferences.name && (
                              <div className="mt-4 p-4 bg-blue-900/20 rounded-xl">
                <p className="text-blue-300">
                  Perfect! Your song will include: <strong>"Welcome {preferences.name}!"</strong>
                </p>
              </div>
              )}
            </div>
          )}

          {/* Step 2: Genre */}
          {currentStep === 2 && (
            <div>
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Music className="h-8 w-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">Choose Your Genre</h2>
                <p className="text-gray-300">What music style fits your vibe?</p>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                {genres.map((genre) => (
                  <button
                    key={genre.id}
                    onClick={() => updatePreferences({ genre: genre.id })}
                    className={`p-4 rounded-2xl border-2 transition-all duration-200 touch-target ${
                      preferences.genre === genre.id
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                        : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <div className={`w-10 h-10 bg-gradient-to-br ${genre.color} rounded-xl flex items-center justify-center mx-auto mb-2`}>
                      <span className="text-xl">{genre.emoji}</span>
                    </div>
                    <h3 className="font-semibold text-gray-900 dark:text-white text-sm">{genre.name}</h3>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 3: Preferences */}
          {currentStep === 3 && (
            <div>
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="h-8 w-8 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">Add Your Touch</h2>
                <p className="text-gray-300">Optional: Make it even more personal</p>
              </div>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-3">
                    What's your mood?
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {moods.map((mood) => (
                      <button
                        key={mood}
                        onClick={() => updatePreferences({ mood: preferences.mood === mood ? '' : mood })}
                        className={`p-3 rounded-xl border-2 text-sm font-medium transition-all duration-200 touch-target ${
                          preferences.mood === mood
                            ? 'border-red-500 bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400'
                            : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300'
                        }`}
                      >
                        {mood}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-3">
                    Favorite artist? (Optional)
                  </label>
                  <input
                    type="text"
                    value={preferences.artist || ''}
                    onChange={(e) => updatePreferences({ artist: e.target.value })}
                    placeholder="e.g., Taylor Swift, The Beatles..."
                    className="input-mobile"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <button
            onClick={handlePrevious}
            disabled={currentStep === 1}
            className={`flex items-center px-6 py-3 rounded-full font-medium transition-all duration-200 touch-target ${
              currentStep === 1
                ? 'text-gray-500 cursor-not-allowed bg-gray-700'
                : 'text-white bg-gray-700 hover:bg-gray-600 border border-gray-600'
            }`}
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back
          </button>

          {currentStep < 3 ? (
            <button
              onClick={handleNext}
              disabled={!canProceed()}
              className={`flex items-center px-6 py-3 rounded-full font-medium transition-all duration-200 touch-target ${
                canProceed()
                  ? 'bg-blue-600 hover:bg-blue-700 text-white'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              Next
              <ArrowRight className="h-5 w-5 ml-2" />
            </button>
          ) : (
            <button
              onClick={handleGenerate}
              disabled={!canProceed()}
              className={`flex items-center px-8 py-3 rounded-full font-bold transition-all duration-200 touch-target ${
                canProceed()
                  ? 'bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
              }`}
            >
              <Sparkles className="h-5 w-5 mr-2" />
              Create My 4-Min Song!
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default GeneratePage;