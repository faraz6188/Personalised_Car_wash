import { UserPreferences } from '../contexts/UserContext';
import { GeneratedSong } from '../contexts/AudioContext';

// Local music files available in the Music directory
const localMusicFiles = [
  {
    id: 'uptown-funk',
    title: 'Uptown Funk',
    filename: 'Uptown-Funk.mp3',
    artist: 'Mark Ronson ft. Bruno Mars',
    genre: 'pop'
  },
  {
    id: 'track-12',
    title: 'Track 12',
    filename: '12Track1222_vbr.mp3',
    artist: 'Unknown Artist',
    genre: 'electronic'
  },
  {
    id: 'love-the-way-you-lie',
    title: 'Love the Way You Lie',
    filename: 'Eminem_Ft_Rihanna_-_Love_the_Way_You_Lie_Offblogmedia.com.mp3',
    artist: 'Eminem ft. Rihanna',
    genre: 'hiphop'
  },
  {
    id: 'chasing-cars',
    title: 'Chasing Cars',
    filename: 'Tommee_Profitt_-_Chasing_Cars_CeeNaija.com_.mp3',
    artist: 'Tommee Profitt',
    genre: 'pop'
  },
  {
    id: 'thinking-out-loud',
    title: 'Thinking Out Loud',
    filename: 'Thinking-Out-Loud.mp3',
    artist: 'Ed Sheeran',
    genre: 'pop'
  }
];

// Import music files for Vite
import uptownFunk from '../Music/Uptown-Funk.mp3';
import track12 from '../Music/12Track1222_vbr.mp3';
import loveTheWayYouLie from '../Music/Eminem_Ft_Rihanna_-_Love_the_Way_You_Lie_Offblogmedia.com.mp3';
import chasingCars from '../Music/Tommee_Profitt_-_Chasing_Cars_CeeNaija.com_.mp3';
import thinkingOutLoud from '../Music/Thinking-Out-Loud.mp3';

// Map filenames to imported assets
const musicAssets: Record<string, string> = {
  'Uptown-Funk.mp3': uptownFunk,
  '12Track1222_vbr.mp3': track12,
  'Eminem_Ft_Rihanna_-_Love_the_Way_You_Lie_Offblogmedia.com.mp3': loveTheWayYouLie,
  'Tommee_Profitt_-_Chasing_Cars_CeeNaija.com_.mp3': chasingCars,
  'Thinking-Out-Loud.mp3': thinkingOutLoud
};

// Generate personalized lyrics based on user preferences
const generateLyrics = (preferences: UserPreferences): string => {
  const { name, genre, mood, artist, vibe } = preferences;
  
  let lyrics = `Welcome ${name}, to your car wash experience!\n`;
  lyrics += `Time to shine and make your car pristine\n`;
  
  // Add genre-specific verses
  switch (genre) {
    case 'pop':
      lyrics += `Dancing bubbles, sparkling clean\n`;
      lyrics += `Your car's the star of this pop scene\n`;
      break;
    case 'rock':
      lyrics += `Rev it up, let's rock and roll\n`;
      lyrics += `Cleaning power, that's our goal\n`;
      break;
    case 'electronic':
      lyrics += `Digital wash, synthetic gleam\n`;
      lyrics += `Electronic car wash dream\n`;
      break;
    case 'jazz':
      lyrics += `Smooth and cool, like morning dew\n`;
      lyrics += `Jazz up your ride, make it new\n`;
      break;
    case 'reggae':
      lyrics += `Easy vibes, no need to rush\n`;
      lyrics += `Island time for your car wash\n`;
      break;
    case 'country':
      lyrics += `Down the road, through dust and grime\n`;
      lyrics += `Country clean, every time\n`;
      break;
    case 'hiphop':
      lyrics += `Beat drops hard, suds fly high\n`;
      lyrics += `Hip-hop wash, reach for the sky\n`;
      break;
    case 'classical':
      lyrics += `Symphony of soap and water\n`;
      lyrics += `Classical clean, as it ought to\n`;
      break;
  }
  
  // Add mood-specific content
  if (mood) {
    lyrics += `Feeling ${mood.toLowerCase()}, that's the way\n`;
    lyrics += `Perfect mood for wash day\n`;
  }
  
  // Add vibe-specific content
  if (vibe) {
    lyrics += `${vibe} vibes filling the air\n`;
    lyrics += `Car wash magic everywhere\n`;
  }
  
  // Add artist inspiration if provided
  if (artist) {
    lyrics += `Like ${artist} would sing it true\n`;
    lyrics += `This song's created just for you\n`;
  }
  
  // Chorus
  lyrics += `\nChorus:\n`;
  lyrics += `Wash away the dust and grime\n`;
  lyrics += `Four minutes of musical time\n`;
  lyrics += `${name}, your car will shine so bright\n`;
  lyrics += `Sgt. Clean Car Wash Tunes makes everything right\n`;
  
  // Bridge
  lyrics += `\nBridge:\n`;
  lyrics += `Soap and bubbles, rinse and dry\n`;
  lyrics += `Your car's ready to touch the sky\n`;
  lyrics += `Thanks for choosing Sgt. Clean Car Wash Tunes today\n`;
  lyrics += `Drive away in style, ${name}!\n`;
  
  return lyrics;
};

/**
 * Select a random music file from the local Music directory
 */
const selectRandomMusicFile = (preferences: UserPreferences) => {
  // Filter music files based on genre preference if available
  let availableFiles = localMusicFiles;
  
  if (preferences.genre) {
    // Try to match genre preference, but fall back to all files if no match
    const genreMatches = localMusicFiles.filter(file => file.genre === preferences.genre);
    if (genreMatches.length > 0) {
      availableFiles = genreMatches;
    }
  }
  
  // Randomly select a file
  const randomIndex = Math.floor(Math.random() * availableFiles.length);
  return availableFiles[randomIndex];
};

/**
 * Generate a personalized song by selecting from local music files
 */
export const generateSong = async (preferences: UserPreferences): Promise<GeneratedSong> => {
  try {
    // Simulate a brief loading time for better UX
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const selectedMusic = selectRandomMusicFile(preferences);
    const lyrics = generateLyrics(preferences);
    
    // Create the audio URL pointing to the local music file
    const audioUrl = musicAssets[selectedMusic.filename];
    
    const song: GeneratedSong = {
      id: `local-song-${Date.now()}`,
      title: `${preferences.name}'s ${selectedMusic.title} Car Wash Experience`,
      audioUrl: audioUrl,
      duration: 240, // 4 minutes as expected
      personalizedGreeting: `Here's your personalized car wash experience with ${selectedMusic.title} by ${selectedMusic.artist}, ${preferences.name}!`,
      createdAt: new Date()
    };

    // Record analytics
    await recordAnalytics({
      songSelected: true,
      genre: preferences.genre,
      selectedMusic: selectedMusic.title,
      hasMood: !!preferences.mood,
      hasArtist: !!preferences.artist,
      hasVibe: !!preferences.vibe,
      duration: 240,
      source: 'local',
      timestamp: new Date().toISOString()
    });

    return song;

  } catch (error) {
    console.error('Error selecting local music:', error);
    
    // Fallback to a default song
    const fallbackMusic = localMusicFiles[0];
    return {
      id: `fallback-song-${Date.now()}`,
      title: `${preferences.name}'s Car Wash Tunes`,
      audioUrl: musicAssets[fallbackMusic.filename],
      duration: 240,
      personalizedGreeting: `Here's your car wash experience, ${preferences.name}!`,
      createdAt: new Date()
    };
  }
};

/**
 * Record analytics data
 */
export const recordAnalytics = async (data: any): Promise<void> => {
  try {
    console.log('Analytics recorded:', data);
    // In production, send to your analytics backend
  } catch (error) {
    console.error('Error recording analytics:', error);
  }
};

/**
 * Health check for TopMediai API
 */
export const healthCheck = async (): Promise<boolean> => {
  try {
    // This function is no longer relevant as we are using local files
    // Keeping it for now, but it will always return true
    return true;
  } catch (error) {
    console.error('Health check failed:', error);
    return false;
  }
};